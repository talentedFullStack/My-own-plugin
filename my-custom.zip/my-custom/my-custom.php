<?php
/**
 * Plugin Name: my-custom
 * Description: Getting Client's Mac address and put it to database in WordPress.
 * Version:     0.0.1
 * Author:      James
 */

// if ( defined( 'ABSPATH' ) && ! defined( 'RWMB_VER' ) ) {
// 	register_activation_hook( __FILE__, 'rwmb_check_php_version' );

// 	/**
// 	 * Display notice for old PHP version.
// 	 */
// 	function rwmb_check_php_version() {
// 		if ( version_compare( phpversion(), '5.3', '<' ) ) {
// 			die( esc_html__( 'Meta Box requires PHP version 5.3+. Please contact your host to upgrade.', 'meta-box' ) );
// 		}
// 	}

// 	require_once dirname( __FILE__ ) . '/inc/loader.php';
// 	$rwmb_loader = new RWMB_Loader();
// 	$rwmb_loader->init();
// }

function UserMac_Address() {
	$MAC = exec('getmac'); 
  
	// Storing 'getmac' value in $MAC 
	$MAC = strtok($MAC, ' '); 
	  
	// Updating $MAC value using strtok function,  
	// strtok is used to split the string into tokens 
	// split character of strtok is defined as a space 
	// because getmac returns transport name after 
	// MAC address    

	sports_bench_create_db();
	
	  global $wpdb;     
	  $table_name = $wpdb->prefix . 'my_table';   
	  $sql = "SELECT * FROM $table_name WHERE content_macaddress = '$MAC' ";  

	  $wpdb->get_results($sql);
			if ($wpdb->num_rows) {
				return;
			} else {
			
				$wpdb->insert($table_name, array('content_id' => $data_1, 'content_macaddress' => $MAC ) );
			}
	  //$wpdb->insert($table_name, array('content_id' => $data_1, 'content_macaddress' => $MAC ) ); 

}

add_action( 'wp_footer', 'UserMac_Address' );


function sports_bench_create_db() {
	 global $wpdb;
	 $charset_collate = $wpdb->get_charset_collate();
	 require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

	 //* Create the teams table
	 $table_name = $wpdb->prefix . 'my_table';
	 $sql = "CREATE TABLE $table_name (
	 content_id INTEGER NOT NULL AUTO_INCREMENT,
	 content_macaddress TEXT NOT NULL,
	 PRIMARY KEY (content_id)
	 ) $charset_collate;";
	 dbDelta( $sql );
	
}





